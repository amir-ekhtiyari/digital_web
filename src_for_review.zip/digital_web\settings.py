from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-sguhpd&kifxm1ke!x1jcw-u49j9e$_v3@p8!-9r4bn)%u^-wez'

DEBUG = True

ALLOWED_HOSTS = []


INSTALLED_APPS = [
    'jazzmin',

    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'accounts.apps.AccountsConfig',
    'orders.apps.OrdersConfig',
    'products.apps.ProductsConfig',
    'mediafiles.apps.MediafilesConfig',
    'core.apps.CoreConfig',
    'contact.apps.ContactConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'digital_web.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / "templates"],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'digital_web.wsgi.application'


# DATABASES = {
#     "default": {
#         "ENGINE": "django.db.backends.sqlite3",
#         "NAME": BASE_DIR / "db.sqlite3",
#     }
# }


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'digital_web_db',
        'USER': 'postgres',
        'PASSWORD': '13821382',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}




AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True


# ---------- STATIC & MEDIA ----------

# خیلی مهم: از ریشه سایت، نه آدرس نسبی
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']



# اگر بعداً برای deploy خواستی collectstatic بزنی، این رو هم می‌تونی داشته باشی:
# STATIC_ROOT = BASE_DIR / 'staticfiles'


MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'


DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# ---------- JAZZMIN ----------

JAZZMIN_SETTINGS = {
    "site_title": "مدیریت فروشگاه فایل دیجیتال",
    "site_header": "پنل مدیریت",
    "welcome_sign": "خوش آمدید به پنل مدیریت فروشگاه فایل‌ها",
    "copyright": "Digital Market © 2025",
    "show_ui_builder": False,
    "language_chooser": True,
}


#تنظیمات ایمیل

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

EMAIL_HOST = "smtp.gmail.com"
EMAIL_USE_TLS = True
EMAIL_PORT = 587
EMAIL_HOST_USER = "your_email@gmail.com"        # ایمیل خودت
EMAIL_HOST_PASSWORD = "16_char_app_password"    # رمز اپلیکیشن
DEFAULT_FROM_EMAIL = "no-reply@yourdomain.com"





LOGIN_URL = "accounts:login"
LOGIN_REDIRECT_URL = "accounts:profile"
